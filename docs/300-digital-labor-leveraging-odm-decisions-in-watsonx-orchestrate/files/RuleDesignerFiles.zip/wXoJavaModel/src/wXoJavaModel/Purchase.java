package wXoJavaModel;

import java.util.Date;
import java.text.ParseException;
import java.util.Calendar;
import java.text.SimpleDateFormat;

public class Purchase {
	String purchaseName;
	Category purchaseCategory;
	Float price;
	Date purchaseDate;
	Integer warrantyDuration;
	WarrantyTypes warrantyType;
	Reason returnReason;
	Condition condition;
	private Date endOfWarrantyDate;

	public Purchase() {
		super();
		this.purchaseName = "Pen";
		this.purchaseCategory = Category.Tools;
		this.condition = Condition.Enter_a_condition;
		this.price = 15.0f;
		this.returnReason = Reason.Enter_a_reason;
		this.purchaseDate = stringToDate("2015-10-05");
		this.setWarrantyDuration(10);
		this.warrantyType = WarrantyTypes.Basic;
	}

	public Purchase(String purchaseName, Category purchaseCategory, Float price, Date purchaseDate, Reason returnReason,
			Condition condition, Integer warranty, WarrantyTypes gType) {
		super();
		this.purchaseName = purchaseName;
		this.purchaseCategory = purchaseCategory;
		this.price = price;
		this.purchaseDate = purchaseDate;
		this.returnReason = returnReason;
		this.condition = condition;
		this.setWarrantyDuration(warranty);
		this.warrantyType = gType;
	}

	public Date endOfwarrantyDate() {
		return endOfWarrantyDate;
	}

	public String endOfwarrantyDate2String() {
		return this.endOfWarrantyDate.toString();
	}

	public Condition getCondition() {
		return condition;
	}

	public void setCondition(Condition condition) {
		this.condition = condition;
	}

	public Integer getWarrantyDuration() {
		return warrantyDuration;
	}

	public void setWarrantyDuration(Integer warrantyDuration) {
		this.warrantyDuration = warrantyDuration;

		Calendar c = Calendar.getInstance();
		c.setTime(this.purchaseDate);
		c.add(Calendar.YEAR, warrantyDuration);
		this.endOfWarrantyDate = c.getTime();
	}

	public WarrantyTypes getWarrantyType() {
		return warrantyType;
	}

	public void setWarrantyType(WarrantyTypes warrantyType) {
		this.warrantyType = warrantyType;
	}

	public String getPurchaseName() {
		return purchaseName;
	}

	public void setPurchaseName(String purchaseName) {
		this.purchaseName = purchaseName;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public String printPurchaseDate() {
		return purchaseDate.toString();
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public Reason getReturnReason() {
		return returnReason;
	}

	public void setReturnReason(Reason returnReason) {
		this.returnReason = returnReason;
	}

	public Category getPurchaseCategory() {
		return purchaseCategory;
	}

	public void setPurchaseCategory(Category purchaseCategory) {
		this.purchaseCategory = purchaseCategory;
	}

	public static Date stringToDate(String dateVlaue) {
		Date date = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		try {

			date = formatter.parse(dateVlaue);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	public void printDetails() {
		System.out.println("----------------------------------------------------------------");
		System.out.println(" Purchase description:");
		System.out.println("  - Name: " + this.purchaseName);
		System.out.println("  - Category: " + this.purchaseCategory);
		System.out.println("  - Price: " + this.price);
		System.out.println("  - Return reason: " + this.returnReason);
		System.out.println("  - Condition: " + this.condition);
		System.out.println("  - Purchase date: " + this.purchaseDate.toString());
		System.out.println("  - Warranty: " + this.warrantyDuration + " year(s)");
		System.out.println("  - Warranty type: " + this.warrantyType + " year(s)");
		System.out.println("  - End of warranty date: " + this.endOfWarrantyDate);
		System.out.println("----------------------------------------------------------------");
	}

}
