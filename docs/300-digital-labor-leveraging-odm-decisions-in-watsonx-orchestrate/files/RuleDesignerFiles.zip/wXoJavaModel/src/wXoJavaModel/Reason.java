package wXoJavaModel;

public enum Reason {
	Enter_a_reason,
	Arrived_damaged,
	Arrived_late,
	Deffective_item,
	No_longer_needed,
	Ordered_by_mistake,
	Unauthorized_order,
	Wrong_item_sent,
	Incorrect_description,
	Out_of_order;
}
