package wXoJavaModel;

public enum ActionType {
Refund, Replace, Repair, CheckItem, Investigate, Close;
}
