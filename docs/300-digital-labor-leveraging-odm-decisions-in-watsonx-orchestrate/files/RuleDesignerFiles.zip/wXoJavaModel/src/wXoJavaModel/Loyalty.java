package wXoJavaModel;

public enum Loyalty {
Basic, Silver, Gold, Platinum;
}
