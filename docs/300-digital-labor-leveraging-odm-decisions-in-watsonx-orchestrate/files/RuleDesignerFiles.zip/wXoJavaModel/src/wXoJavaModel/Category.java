package wXoJavaModel;

public enum Category {
	Beauty,
	Books,
	Clothing,
	Electronics,
	Furniture,
	Garden,
	Jewelry,
	Grocery,
	Pets,
	Tools,
	Toys;
}
