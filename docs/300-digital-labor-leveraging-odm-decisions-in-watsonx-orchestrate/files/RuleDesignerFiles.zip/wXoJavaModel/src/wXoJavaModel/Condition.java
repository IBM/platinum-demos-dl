package wXoJavaModel;

public enum Condition {
Enter_a_condition, Opened, Used, Unopened, Damaged;
}
