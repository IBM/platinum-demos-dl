package wXoJavaModel;

public enum Country {
USA, Canada, Other;
}
