# This file is to be used with CP4BA 23.0.1 Starter deployment to remove the Content Platinum Demo artifacts (except Teamspace-related artifacts)

# Set all variables according to your environment before executing this file

#----------------------------------------------------------------------------------------------------------
# Specify below variables to launch the deployment automation with
#----------------------------------------------------------------------------------------------------------

# Either 'pakInstallerPortalURL' or 'ocLoginServer' and 'ocLoginToken' need to be specified but not both depending on how the environment is installed

# URL of the PakInstaller Portal ('PakInstaller Portal URL:') from the bottom of the environment reservation when deployed from TechZone via PakInstaller
pakInstallerPortalURL=REQUIRED

# Value of the 'server' parameter as shown on the 'Copy login command' page in the OCP web console
#ocLoginServer=REQUIRED
# Value shown under 'Your API token is' or as 'token' parameter as shown on the 'Copy login command' page in the OCP web console
#ocLoginToken=REQUIRED


# Uncomment in case JVM throws an "Out Of Memory"-exception during the execution
#jvmSettings="-Xms4096M"

# Uncomment in case GitHub is not accessible and all resources are already available locally
#disableAccessToGitHub="-disableAccessToGitHub=true"

# Proxy settings in case a proxy server needs to be used to access the GitHub resources
# Uncomment at least the proxScenatio, proxyHost, and proxyPort lines and set values accordingly in case a proxy server needs to be used to access GitHub
# Uncomment the lines proxyUser and proxyPwd too, in case the proxy server requires authentication
#proxyScenario=GitHub
#proxyHost=
#proxyPort=
#proxyUser=
#proxyPwd=

# Specific trace string for the boostrapping process (only uncomment if instructed to do so)
#bootstrapDebugString="\"-bootstrapDebugString=*=finest\""


# ----------------------------------------------------------------------------------------------------------
# Construct the proxy settings for curl and deployment automation tool if proxy is configured
# ----------------------------------------------------------------------------------------------------------

if [ ! -z "${proxyHost+x}" ]
then
  if [ ! -z "${proxyUser+x}" ]
  then
     TOOLPROXYSETTINGS=-"proxyScenario=${proxyScenario} -proxyHost=${proxyHost} -proxyPort=${proxyPort} -proxyUser=${proxyUser} -proxyPwd=${proxyPwd}"

     if [[ "${proxyScenario}" == "GitHub" ]] 
     then
       CURLPROXYSETTINGS="-x ${proxyHost}:${proxyPort} -U ${proxyUser}:${proxyPwd}"
     fi
  else
    TOOLPROXYSETTINGS="-proxyScenario=${proxyScenario} -proxyHost=${proxyHost} -proxyPort=${proxyPort}"
    if [[ "${proxyScenario}" == "GitHub" ]] 
    then
       CURLPROXYSETTINGS="-x ${proxyHost}:${proxyPort}"
    fi
  fi
fi

# ----------------------------------------------------------------------------------------------------------
# Global settings for the script (not to be modified by user)
# ----------------------------------------------------------------------------------------------------------

# CP4BA version
CP4BAVERSION="23.0.1"
# Deployment pattern of the CP4BA instance
DEPLOYMENTPATTERN="Starter"
# Name of the configuration file to use when running the deployment automation tool
CONFIGNAME="config-undeploy-content"
# Automation script to use when running the deployment automation tool
AUTOMATIONSCRIPT="RemoveContentPlatinumDemoArtifacts.json"

# Name of the source sh file passed to execution environment
SCRIPTNAME=removeContentPlatinumDemoStarter.sh
# Name of the actual sh file passed to execution environment
FILENAME=$0
# Version of this script file passed to execution environment
SCRIPTVERSION=1.0.0

# ----------------------------------------------------------------------------------------------------------
# Validate that the deployment tool jar is available locally
# ----------------------------------------------------------------------------------------------------------

toolValidationSuccess=true

# 
if ls *DeploymentAutomation.jar 1> /dev/null 2>&1; then
  # get the latest version of the file
  TOOLFILENAME=$(ls *DeploymentAutomation.jar | tail -n 1)
    
  echo "  Using local deployment automation jar file '${TOOLFILENAME}'"
# if no file with the name found 
else
  toolValidationSuccess=false
  echo "  No version of the deployment automation jar could be found while retrieval from GitHub is disabled"
fi

echo

# ----------------------------------------------------------------------------------------------------------
# Validation that all required parameters are set
# ----------------------------------------------------------------------------------------------------------

validationSuccess=true

# if 'pakInstallerPortalURL' is not defined or set as default or empty then check that 'ocLoginServer' and 'ocLoginToken' are properly defined
if [ -z "${pakInstallerPortalURL+x}" ] || [[ "${pakInstallerPortalURL}" == "REQUIRED" ]] || [[ "${pakInstallerPortalURL}" == "" ]]
then
	if [ -z "${ocLoginServer+x}" ] || [[ "${ocLoginServer}" == "REQUIRED" ]] || [[ "${ocLoginServer}" == "" ]]
	then
		if $validationSuccess
		then
			echo "Validating configuration failed:"
			validationSuccess=false
		fi
		echo "  Variable 'ocLoginServer' has not been defined/set (nor is variable 'pakInstallerPortalURL' defined/set)"
	else
		INTERNALOCLOGINSERVER=-ocLoginServer=${ocLoginServer}
	fi
	
	if [ -z "${ocLoginToken+x}" ] || [[ "${ocLoginToken}" == "REQUIRED" ]] || [[ "${ocLoginToken}" == "" ]]
	then
		if $validationSuccess
		then
			echo "Validating configuration failed:"
			validationSuccess=false
		fi
		echo "  Variable 'ocLoginToken' has not been defined/set (nor is variable 'pakInstallerPortalURL' defined/set)"
	else
		INTERNALOCLOGINTOKEN=-ocLoginToken=${ocLoginToken}
	fi
else 
	if ([[ "${ocLoginServer}" != "REQUIRED" ]] && [[ "${ocLoginServer}" != "" ]]) || ([[ "${ocLoginToken}" != "REQUIRED" ]] && [[ "${ocLoginToken}" != "" ]])
	then
		if $validationSuccess
		then
			echo "Validating configuration failed:"
			validationSuccess=false
		fi
		echo "  Either 'ocLoginServer' and 'ocLoginToken' or 'pakInstallerPortalURL' can be specified but NOT both"
	else
		INTERNALPAKINSTALLERPORTALURL=-pakInstallerPortalURL=${pakInstallerPortalURL}
	fi
fi

if ! $validationSuccess
then
  echo
fi

if ! $validationSuccess || ! $toolValidationSuccess
then
  echo "Exiting..."
  exit 1
fi

java ${jvmSettings} -jar ${TOOLFILENAME} ${bootstrapDebugString} \"-scriptName=${FILENAME}\" \"-scriptSource=${SCRIPTNAME}\" \"-scriptVersion=${SCRIPTVERSION}\" ${INTERNALOCLOGINSERVER} ${INTERNALOCLOGINTOKEN} ${INTERNALPAKINSTALLERPORTALURL} ${TOOLPROXYSETTINGS} -installBasePath=${DEPLOYMENTPATTERN} -config=${CONFIGNAME} -automationScript=${AUTOMATIONSCRIPT} -isLocalMode